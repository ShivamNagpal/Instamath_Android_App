package com.nagpal.shivam.instamath.Utils;

public class EntryValue {
    private double mX;
    private double mY;

    public EntryValue(double x, double y) {
        mX = x;
        mY = y;
    }

    public double getX() {
        return mX;
    }

    public double getY() {
        return mY;
    }

}