package com.nagpal.shivam.instamath.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ListView;

import com.nagpal.shivam.instamath.Adapter.ActivityInfoAdapter;
import com.nagpal.shivam.instamath.R;
import com.nagpal.shivam.instamath.Utils.ActivityDetail;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static ArrayList<ActivityDetail> mActivityDetailArrayList;
    private AutoCompleteTextView actvSearch;
    private Toolbar toolbar;
    private Boolean isSearchOpen = false;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (isSearchOpen) {
            getMenuInflater().inflate(R.menu.menu_search_open_main_activity, menu);
        } else {
            getMenuInflater().inflate(R.menu.menu_search_close_main_activity, menu);
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (isSearchOpen) {
                    closeSearch();
                }
                return true;

            case R.id.search_open_menu_item:
                openSearch();
                return true;

            case R.id.search_clear_menu_item:
                actvSearch.setText(null);
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = (Toolbar) findViewById(R.id.main_activity_toolbar_default);
        setSupportActionBar(toolbar);


        mActivityDetailArrayList = new ArrayList<>();

        mActivityDetailArrayList.add(new ActivityDetail("Basic Calculator", BasicCalculatorActivity.class));
        mActivityDetailArrayList.add(new ActivityDetail("Scientific Calculator", ScientificCalculatorActivity.class));
        mActivityDetailArrayList.add(new ActivityDetail("Simple Interest", SimpleInterestActivity.class));
        mActivityDetailArrayList.add(new ActivityDetail("Interpolation", InterpolationActivity.class));

        ArrayList<String> activityNamesArrayList = new ArrayList<>();

        for (ActivityDetail activityDetail : mActivityDetailArrayList) {
            activityNamesArrayList.add(activityDetail.getName());
        }

        actvSearch = new AutoCompleteTextView(this);
        actvSearch.setTextColor(ContextCompat.getColor(this, android.R.color.white));
        actvSearch.setLayoutParams(new Toolbar.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        actvSearch.setSingleLine();
        actvSearch.setHintTextColor(ContextCompat.getColor(this, android.R.color.white));
        actvSearch.setHint("Search");
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, activityNamesArrayList);
        actvSearch.setAdapter(arrayAdapter);
        actvSearch.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selectedItem = parent.getAdapter().getItem(position).toString();

                for (ActivityDetail aI : mActivityDetailArrayList) {
                    if (aI.getName().equals(selectedItem)) {
                        startActivity(new Intent(MainActivity.this, aI.getActivityClass()));
                    }
                }
            }
        });


        ListView listView = (ListView) findViewById(R.id.list_view_activity);

        ActivityInfoAdapter activityInfoAdapter = new ActivityInfoAdapter(this, mActivityDetailArrayList);

        listView.setAdapter(activityInfoAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(MainActivity.this, mActivityDetailArrayList.get(i).getActivityClass());
                startActivity(intent);
            }
        });
    }

    private void openSearch() {
        isSearchOpen = true;

        actvSearch.requestFocus();
        invalidateOptionsMenu();
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.addView(actvSearch);
    }

    private void closeSearch() {
        isSearchOpen = false;
        actvSearch.setText(null);
        toolbar.removeView(actvSearch);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        }
        invalidateOptionsMenu();
    }
}
