package com.nagpal.shivam.instamath.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.nagpal.shivam.instamath.R;

public class CompoundInterestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compound_interest);
    }
}
